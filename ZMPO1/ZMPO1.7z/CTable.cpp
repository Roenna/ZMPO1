#include "CTable.h"

CTable::CTable() {
	this->i_tableLength = TAB_LENGTH;
	this->s_name = TAB_NAME;
	i_table = new int[i_tableLength];

	for (int i = 0; i < i_tableLength; i++) {
		i_table[i] = 0; //zerowanie tablicy, bo sa smieci
	}

	cout << "bezp: '" << s_name << "'" << endl;
}

CTable::CTable(string sName) {
	this->i_tableLength = TAB_LENGTH;
	this->s_name = sName;
	i_table = new int[i_tableLength];

	for (int i = 0; i < i_tableLength; i++) {
		i_table[i] = 0; //zerowanie tablicy, bo sa smieci
	}

	cout << "parametr: '" << sName << "'" << endl;
}

CTable::CTable(const CTable & pcOther) {
	s_name = pcOther.s_name + "_copy";
	i_tableLength = pcOther.i_tableLength;
	i_table = new int[i_tableLength];

	int tmp_val = 0;

	for (int i = 0; i < i_tableLength; i++) {
		pcOther.bGetValue(&tmp_val, i); //pobieranie wartosci z tablicy
		i_table[i] = tmp_val; //i wstawianie do nowej
	}

	cout << "kopiuj: ' " << s_name << "'" << endl;
}

string CTable::sGetName() {
	return s_name;
}

void CTable::vSetName(string sName) {
	s_name = sName;
}

string CTable::sGetFull() {
	string sValues = "";
	for (int i = 0; i < i_tableLength; i++) {
		if (i>0) sValues += ", ";
		sValues += to_string(i_table[i]);
	}
	string sInf = s_name + " " + "len: " + to_string(i_tableLength) + " values: " + sValues;
	return sInf;
}

bool CTable::bGetValue(int* ptr_value, int iIndex)const {
	if (iIndex >= i_tableLength)
		return false;
	else {
		*ptr_value = *(i_table + iIndex); //zwracam adres elementu na danej pozycji w tablicy
		return true;
	}
}

bool CTable::bSetValue(int iValue, int iIndex) {
	if (iIndex > i_tableLength)
		return false;
	else {
		i_table[iIndex] = iValue;
		return true;
	}
}

int CTable::iGetTableLength() {
	return i_tableLength;
}

void CTable::vSetTableLength(int iTableLength) {
	int* old_table = i_table; //zapisujemy adres starej tab
	int* new_table = new int[iTableLength]; //tworzymy nowa tab 

	//w ogole to zawczasu wypelnilabym te nowa 0...

	for (int i = 0; i < iTableLength; i++) {
		new_table[i] = 0; //zerowanie tablicy, bo sa smieci
	}

	for (int i = 0; i < i_tableLength; i++) { //dodajemy wartosci idac po indeksach starej tablicy
		if (i < iTableLength) { //index < dl nowej tab, jak wiekszy, to kuniec
			new_table[i] = old_table[i];
		}
		else {
			break;
		}
	}
	delete[] old_table; //usuwamy stara tablice
	i_table = new_table; //przypisujemy nowa 

	i_tableLength = iTableLength; //oraz dlugosc
}

void CTable::vDoNothing(CTable obj) { //rob nic, poniewaz.

}

CTable::~CTable() {
	delete i_table;
	cout << "usuwam: " << s_name << endl;
}

CTable & CTable::operator= (const CTable &c) { //no jak dla mnie to prawie jak kopiujacy
	s_name = c.s_name;
	i_tableLength = c.i_tableLength;
	i_table = new int[i_tableLength];

	int tmp_val = 0;

	for (int i = 0; i < i_tableLength; i++) {
		c.bGetValue(&tmp_val, i); //pobieranie wartosci z tablicy
		i_table[i] = tmp_val; //i wstawianie do nowej
	}
	return *this;
}

CTable CTable::operator+ ( CTable &c) {
	CTable temp;
	temp.s_name = s_name + " + " + c.s_name;
	temp.i_tableLength = i_tableLength + c.i_tableLength;
	temp.i_table = new int[temp.i_tableLength];
	int i = 0, j = 0;
	while (i < i_tableLength) {
		if (i_table[i] != 0) {
			temp.i_table[j] = i_table[i];
			i++;
			j++;
		}
		else
			i++;
	}
	i = 0;
	while (i < c.i_tableLength) {
		if (c.i_table[i] != 0) {
			temp.i_table[j] = c.i_table[i];
			i++;
			j++;
		}
		else
			i++;
	}
	temp.i_tableLength = j; //bo po dodaniu ostatniego el i tak doda�o sie 1
	return temp;
}

CTable CTable::operator- (CTable &c) {
	CTable temp;
	temp.s_name = s_name + " - " + c.s_name;
	temp.i_tableLength = i_tableLength + c.i_tableLength;
	temp.i_table = new int[temp.i_tableLength];
	int i = 0, j = 0;
	while (i < c.i_tableLength) {
		if (!bContains(c.i_table[i]) && c.i_table[i]!=0) {
			temp.i_table[j] = c.i_table[i];
			i++;
			j++;
		}
		else
			i++;
		
	}
	temp.i_tableLength = j; //bo po dodaniu ostatniego el i tak doda�o sie 1
	return temp;
}

CTable CTable::operator* (CTable &c) {
	CTable temp;
	temp.s_name = s_name + " * " + c.s_name;
	temp.i_tableLength = i_tableLength + c.i_tableLength;
	temp.i_table = new int[temp.i_tableLength];
	int i = 0, j = 0;
	while (i < c.i_tableLength) {
		if (bContains(c.i_table[i]) && c.i_table[i] != 0) {
			temp.i_table[j] = c.i_table[i];
			i++;
			j++;
		}
		else
			i++;
		
	}
	temp.i_tableLength = j; //bo po dodaniu ostatniego el i tak doda�o sie 1
	return temp;
}

bool CTable::bContains(int value) {
	bool contains = false;
	for (int i = 0; i < i_tableLength; i++) {
		if (i_table[i] == value)
			contains = true;
	}
	return contains;
}
	//CTable operator * (const CTable &c);


